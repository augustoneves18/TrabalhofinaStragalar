CREATE DATABASE IF NOT EXISTS db_stragalar CHARACTER SET utf8mb4;
USE db_stragalar;

CREATE TABLE IF NOT EXISTS usuario (
    idUsuario INT PRIMARY KEY AUTO_INCREMENT,
    nomeUsuario VARCHAR(100) NOT NULL,
    login VARCHAR(50) NOT NULL UNIQUE,
    senha VARCHAR(200) NOT NULL,
    funcao ENUM('Admin', 'Operador de Caixa', 'Estoquista') NOT NULL,
    ativo BOOLEAN NOT NULL DEFAULT TRUE,
    dataCadastro DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS produto (
    idProduto INT PRIMARY KEY AUTO_INCREMENT,
    nomeProduto VARCHAR(100) NOT NULL,
    categoria VARCHAR(45) NOT NULL,
    unidadeMedida VARCHAR(45) NOT NULL,
    preco DECIMAL(10,2) NOT NULL DEFAULT 0,
    quantidadeEstoque DECIMAL(10,3) NOT NULL DEFAULT 0,
    dataValidade DATE NULL,
    dataEntrada DATE NULL,
    ativo BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS caixa (
    idCaixa INT PRIMARY KEY AUTO_INCREMENT,
    idUsuarioAbertura INT NOT NULL,
    idUsuarioFechamento INT NULL,
    dataAbertura DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    dataFechamento DATETIME NULL,
    valorAbertura DECIMAL(10,2) NOT NULL DEFAULT 0,
    valorContadoFechamento DECIMAL(10,2) NULL,

    FOREIGN KEY (idUsuarioAbertura) REFERENCES usuario(idUsuario),
    FOREIGN KEY (idUsuarioFechamento) REFERENCES usuario(idUsuario)
);

CREATE TABLE IF NOT EXISTS venda (
    idVenda INT PRIMARY KEY AUTO_INCREMENT,
    idCaixa INT NOT NULL,
    idUsuario INT NOT NULL,
    dataVenda DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    valorTotal DECIMAL(10,2) NOT NULL DEFAULT 0,
    status BOOLEAN NOT NULL DEFAULT FALSE,

    FOREIGN KEY (idCaixa) REFERENCES caixa(idCaixa),
    FOREIGN KEY (idUsuario) REFERENCES usuario(idUsuario)
);

CREATE TABLE IF NOT EXISTS itemVenda (
    idItemVenda INT PRIMARY KEY AUTO_INCREMENT,
    idVenda INT NOT NULL,
    idProduto INT NOT NULL,
    quantidade DECIMAL(10,3) NOT NULL,
    precoUnitario DECIMAL(10,2) NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,

    FOREIGN KEY (idVenda) REFERENCES venda(idVenda),
    FOREIGN KEY (idProduto) REFERENCES produto(idProduto)
);

CREATE TABLE IF NOT EXISTS movimentacaoCaixa (
    idMovimentacaoCaixa INT PRIMARY KEY AUTO_INCREMENT,
    idCaixa INT NOT NULL,
    idUsuario INT NOT NULL,
    idVenda INT NULL,
    tipo ENUM('Entrada', 'Saída') NOT NULL,
    origem ENUM('Venda', 'Sangria', 'Estorno', 'Estoque') NOT NULL,
    formaPagamento ENUM('Dinheiro', 'Pix', 'Débito', 'Crédito', 'Outros') NOT NULL,
    descricao VARCHAR(200) NOT NULL,
    valor DECIMAL(10,2) NOT NULL,
    dataMovimentacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (idCaixa) REFERENCES caixa(idCaixa),
    FOREIGN KEY (idUsuario) REFERENCES usuario(idUsuario),
    FOREIGN KEY (idVenda) REFERENCES venda(idVenda)
);

CREATE TABLE IF NOT EXISTS movimentacaoEstoque (
    idMovimentacaoEstoque INT PRIMARY KEY AUTO_INCREMENT,
    idUsuario INT NOT NULL,
    idProduto INT NOT NULL,
    tipo ENUM('Entrada', 'Saída') NOT NULL,
    quantidade DECIMAL(10,3) NOT NULL,
    motivo VARCHAR(200) NOT NULL,
    dataMovimentacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (idUsuario) REFERENCES usuario(idUsuario),
    FOREIGN KEY (idProduto) REFERENCES produto(idProduto)
);

INSERT INTO usuario (nomeUsuario, login, senha, funcao) VALUES
    ('Administrador', 'admin', 'teste123', 'Admin'),
    ('Operador de Caixa', 'operador', 'teste123', 'Operador de Caixa'),
    ('Estoquista', 'estoquista', 'teste123', 'Estoquista');

INSERT INTO produto (nomeProduto, categoria, unidadeMedida, preco, quantidadeEstoque) VALUES
    ('Água mineral', 'Bebidas', 'un', 7.50, 48.000),
    ('Refrigerante lata', 'Bebidas', 'un', 6.00, 36.000),
    ('Suco de laranja', 'Bebidas', 'L', 16.00, 8.500),
    ('Batata frita', 'Porções', 'kg', 48.00, 9.500),
    ('Porção de mandioca', 'Porções', 'un', 22.00, 20.000),
    ('X-búrguer', 'Lanches', 'un', 19.90, 25.000),
    ('Prato executivo', 'Pratos', 'un', 29.90, 18.000),
    ('Pudim', 'Sobremesas', 'un', 9.50, 15.000);

INSERT INTO movimentacaoEstoque (idUsuario, idProduto, tipo, quantidade, motivo) VALUES
    (1, 1, 'Entrada', 48.000, 'Estoque inicial de teste'),
    (1, 2, 'Entrada', 36.000, 'Estoque inicial de teste'),
    (1, 3, 'Entrada', 8.500, 'Estoque inicial de teste'),
    (1, 4, 'Entrada', 9.500, 'Estoque inicial de teste'),
    (1, 5, 'Entrada', 20.000, 'Estoque inicial de teste'),
    (1, 6, 'Entrada', 25.000, 'Estoque inicial de teste'),
    (1, 7, 'Entrada', 18.000, 'Estoque inicial de teste'),
    (1, 8, 'Entrada', 15.000, 'Estoque inicial de teste');
